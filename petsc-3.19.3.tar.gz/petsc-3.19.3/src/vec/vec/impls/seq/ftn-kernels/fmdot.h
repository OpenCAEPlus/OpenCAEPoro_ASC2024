
#ifndef __FMDOT_H
#define __FMDOT_H

#include <petscsys.h>
#if defined(PETSC_USE_FORTRAN_KERNEL_MDOT)
  #if defined(PETSC_HAVE_FORTRAN_CAPS)
    #define fortranmdot4_ FORTRANMDOT4
    #define fortranmdot3_ FORTRANMDOT3
    #define fortranmdot2_ FORTRANMDOT2
    #define fortranmdot1_ FORTRANMDOT1
  #elif !defined(PETSC_HAVE_FORTRAN_UNDERSCORE)
    #define fortranmdot4_ fortranmdot4
    #define fortranmdot3_ fortranmdot3
    #define fortranmdot2_ fortranmdot2
    #define fortranmdot1_ fortranmdot1
  #endif
PETSC_EXTERN void fortranmdot4_(const void *, const void *, const void *, const void *, const void *, const PetscInt *, void *, void *, void *, void *);
PETSC_EXTERN void fortranmdot3_(const void *, const void *, const void *, const void *, const PetscInt *, void *, void *, void *);
PETSC_EXTERN void fortranmdot2_(const void *, const void *, const void *, const PetscInt *, void *, void *);
PETSC_EXTERN void fortranmdot1_(const void *, const void *, const PetscInt *, void *);
#endif
#endif
